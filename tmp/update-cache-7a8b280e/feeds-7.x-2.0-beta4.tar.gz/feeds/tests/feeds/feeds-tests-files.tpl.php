Title,published,file,GUID,alt,title2
"Tubing is awesome",205200720,<?php print $files[0]; ?>,0,Alt text 0,Title text 0
"Jeff vs Tom",428112720,<?php print $files[1]; ?>,1,Alt text 1,Title text 1
"Attersee",1151766000,<?php print $files[2]; ?>,2,Alt text 2,Title text 2
"H Street NE",1256326995,<?php print $files[3]; ?>,3,Alt text 3,Title text 3
"La Fayette Park",1256326995,<?php print $files[4]; ?>,4,Alt text 4,Title text 4
